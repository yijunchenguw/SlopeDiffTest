# slopediff_one_pair function
#
# Users can test one pair of predictors in their model of predictors in their model (assume an experimentwise alpha of .05, 2-tailed).
#
# This is the initial version of function named 'slopediff_one_pair'
# which prints "Difference Pair", "Coef", "SE", "t", "df", "p", "95%CILB", "95%CIUB".
#
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'


# diff function for one pair of predictors ----
slopediff_one_pair <-
  function(model,
           predictor1name,
           predictor2name,
           Round = TRUE,
           Decimal = 3, verbose = TRUE)
  {
    t_test <- 0
    Result <- .slpdiff_private(model, predictor1name, predictor2name)
    final <- .print_coef_diff(subset(Result, select = -t_test), Round, Decimal, t.test = Result$t_test, verbose)
    invisible(final)

  }

.slpdiff_private <- function(model, predictor1name, predictor2name)
{
  slope_diff_coef <- 0
  slope_diff_df <- 0
  is_t_test <- FALSE
  slope_diff_p <- 0
  slope_diff_t <- 0
  slope_diff_z <- 0
  z.score <- 1.96
  t.score <- 0
  slope_diff_SE <- 0
  slope_diff_LB <- 0
  slope_diff_UB <- 0
  # lm and glm model -----
  if ("lm" %in%  class(model)[1]) {
    if (!(predictor1name %in%  names(model$coefficients)) |
        !(predictor2name %in%  names(model$coefficients)))
      stop("Please type in correct predictor name!")
    # get coeff diffs
    b1 = summary(model)$coefficients[predictor1name, "Estimate"]
    b2 = summary(model)$coefficients[predictor2name, "Estimate"]
    slope_diff_coef <- b1 - b2

    # var and SE
    var_b1 = vcov(model)[predictor1name, predictor1name]
    var_b2 = vcov(model)[predictor2name, predictor2name]
    cov_b1b2 = vcov(model)[predictor1name, predictor2name]
    slope_diff_SE <- sqrt(var_b1 + var_b2 - 2 * cov_b1b2)
    # lm model -----
    if (length(class(model)) == 1) {
      slope_diff_df <- model$df.residual
      slope_diff_t <- slope_diff_coef / slope_diff_SE
      slope_diff_p <-
        2 * pt(q = abs(slope_diff_t),
               df = slope_diff_df,
               lower.tail = FALSE)
      t.score = qt(p = 0.05 / 2,
                   df = slope_diff_df,
                   lower.tail = F)
      is_t_test <- TRUE
    }
    # glm model -----
    else if (length(class(model)) == 2) {
      slope_diff_df <- 0
      is_t_test <- FALSE
      slope_diff_z <- slope_diff_coef / slope_diff_SE
      # glm model p value -----
      slope_diff_p <-
        2 * pnorm(
          q = abs(slope_diff_z),
          mean = 0,
          sd = 1,
          lower.tail = FALSE
        )
      z.score = 1.96
    }
  }
  # lme model -----
  else if ("lme" %in% class(model))
  {
    names <- names(coef(summary(model))[, "Value"])
    if (!(predictor1name %in% names) | !(predictor2name %in% names))
      stop("Please type in correct predictor name!")
    # get coeff diffs
    slope_diff_coef <-
      as.numeric(coef(summary(model))[, "Value"][predictor1name] -
                   coef(summary(model))[, "Value"][predictor2name])
    # var and SE
    slope_diff_SE = sqrt((vcov(model))[predictor1name, predictor1name] +
                           (vcov(model))[predictor2name, predictor2name] -
                           2 * (vcov(model))[predictor1name, predictor2name])
    # df
    slope_diff_df = min(coef(summary(model))[, "DF"][predictor1name],
                        coef(summary(model))[, "DF"][predictor2name])
    # t and t score
    slope_diff_t <- slope_diff_coef / slope_diff_SE
    t.score = qt(p = 0.05 / 2,
                 df = slope_diff_df,
                 lower.tail = F)
    is_t_test <- TRUE
    #### in general: p associated with t-value = 2*pt(q=abs(L1_slope_diff_t), df=(L1_slope_diff_df), lower.tail=FALSE)
    slope_diff_p <-
      2 * pt(
        q = abs(slope_diff_t),
        df = (slope_diff_df),
        lower.tail = FALSE
      )
  }
  # lmer and glmer model ----
  else {
    names <- names(coef(summary(model))[, "Estimate"])
    if (!(predictor1name %in% names) | !(predictor2name %in% names))
      stop("Please type in correct predictor name!")
    # get coeff diffs
    slope_diff_coef <-
      as.numeric(coef(summary(model))[, "Estimate"][predictor1name] -
                   coef(summary(model))[, "Estimate"][predictor2name])
    # var and SE
    slope_diff_SE <-
      sqrt((vcov(model))[predictor1name, predictor1name] +
             (vcov(model))[predictor2name, predictor2name] -
             2 * (vcov(model))[predictor1name, predictor2name])

    # lmer model -----
    if ("lmerModLmerTest" %in% class(model)) {

      slope_diff_t <- slope_diff_coef / slope_diff_SE
      slope_diff_df <-
        min(coef(summary(model))[, "df"][predictor1name],
            coef(summary(model))[, "df"][predictor2name])
      slope_diff_p <-
        2 * pt(
          q = abs(slope_diff_t),
          df = (slope_diff_df),
          lower.tail = FALSE
        )
      # t and t score
      is_t_test <- TRUE
      t.score = qt(p = 0.05 / 2,
                   df = slope_diff_df,
                   lower.tail = F)
    }
    # glmer model -----
    else if ("glmerMod" %in% class(model)) {
      #print("glmer")
      slope_diff_df <- 0
      # z and z score
      slope_diff_z <- slope_diff_coef / slope_diff_SE
      z.score <- 1.96
      # different p value
      slope_diff_p <-
        2 * pnorm(
          q = abs(slope_diff_z),
          mean = 0,
          sd = 1,
          lower.tail = FALSE
        )
    }
  }
  if (is_t_test) {
    # lower and upper bounds ----
    slope_diff_LB <- slope_diff_coef - t.score * slope_diff_SE
    slope_diff_UB <- slope_diff_coef + t.score * slope_diff_SE
  } else{
    slope_diff_LB <- slope_diff_coef - z.score * slope_diff_SE
    slope_diff_UB <- slope_diff_coef + z.score * slope_diff_SE
  }
  Result_pariwise <-
    .prepare_result(
      predictor1name,
      predictor2name,
      slope_diff_coef,
      slope_diff_SE,
      slope_diff_df,
      is_t_test,
      slope_diff_p,
      slope_diff_t,
      slope_diff_z,
      slope_diff_LB,
      slope_diff_UB
    )
  return(as.data.frame(Result_pariwise))
}

# build up the return data frame ----
.prepare_result <-
  function(predictor1,
           predictor2,
           slope_diff_coef,
           slope_diff_SE,
           df,
           is_t,
           slope_diff_p,
           slope_diff_t = NULL,
           slope_diff_z = NULL,
           slope_diff_LB,
           slope_diff_UB)
  {
    Result_pariwise <- c()
    Result_pariwise$"Predictor 1" <- predictor1
    Result_pariwise$"Predictor 2" <- predictor2
     # c(paste(predictor1,'|', predictor2))
    Result_pariwise$"diff_coef" <- slope_diff_coef
    Result_pariwise$"diff_SE" <- slope_diff_SE
    if (is_t) {
      Result_pariwise$"diff_t" <-
        slope_diff_t
      Result_pariwise$"diff_df" <-
        df
    } else{
      Result_pariwise$"diff_z" <-
        slope_diff_z
    }
    Result_pariwise$"diff_p" <- slope_diff_p
    Result_pariwise$"diff_LB" <-
      slope_diff_LB
    Result_pariwise$"diff_UB" <-
      slope_diff_UB
    Result_pariwise$"t_test" <- is_t
    return(Result_pariwise)
  }

.print_coef_diff <- function(x, Round, Decimal, t.test = FALSE, verbose = TRUE)
{
  Cf <- cbind(x[1],x[2])
  names <- colnames(x)
  xm <- data.matrix(x[, ])

  for (index in c(3:length(names)))
  {
    if (dim(x)[1] > 1)
      pv <- as.vector(xm[, index]) # drop names
    else
      pv <- as.vector(xm[index])
      tempNames <- cbind(colnames(Cf))

    if (grepl("p", names[index])) {
      Signif <- symnum(
        pv,
        corr = FALSE,
        na = FALSE,
        cutpoints = c(0,  .001, .01, .05, .1, 1),
        symbols   =  c("***", "**", "*", ".", " ")
      )
      data <- ifelse(Round, round(x[index], Decimal), x[index])
      data <- as.vector(data[[1]])
      if (Round)
        data <- replace(data, data < 0.0001, "<0.000")
      Cf <- cbind(Cf, data)
      colnames(Cf) <- c(tempNames, names[index])
      tempNames <- colnames(Cf)
      Cf <- cbind(Cf, format(Signif)) #format.ch: right=TRUE
      colnames(Cf) <- c(tempNames, " ")
    }
    else {
      Cf <- cbind(Cf, ifelse(Round, round(x[index], Decimal), x[index]))
      colnames(Cf) <- c(tempNames, names[index])

    }
  }
  if(verbose){
  print(Cf)
  if ((w <-
       getOption("width")) < nchar(sleg <- attr(Signif, "legend")))
    # == 46
    sleg <- strwrap(sleg, width = w - 2, prefix = "  ")
  ##"FIXME": Double space __ is for reproducibility, rather than by design
  if (t.test == FALSE)
    cat(
      "---\nZ-test used for comparisons \nSignif. codes:  ",
      sleg,
      sep = "",
      fill = w + 4 + max(nchar(sleg, "bytes") - nchar(sleg))
    )# +4: "---"
  else
    cat(
      "---\nSignif. codes:  ",
      sleg,
      sep = "",
      fill = w + 4 + max(nchar(sleg, "bytes") - nchar(sleg))
    )# +4: "---"
  if(dim(x)[1] > 1){
    cat("Note: Bon = Bonferroni \n      S = Sidak \n      BH = Benjamini Hochberg new\n")
    }
  }
   invisible(Cf)
}
