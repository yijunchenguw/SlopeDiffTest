# slopediff_all_pairs function
#
# Users can test all possible pairs of predictors in their model (the latter includes three types of p-value adjustments for determining significance: the Bonferroni, Dunn-Sidak, and Benjamini-Hochberg, assuming an experimentwise alpha of .05, 2-tailed).
#
# This is the initial version of function named 'slopediff_all_pairs'
# which prints slope_diff_coeff, slope_diff_t, slope_diff_df, slope_diff_p and adjusted p-value of Bonferroni, Sidak, Benjamini Hochberg.
#
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Cmd + Shift + B'
#   Check Package:             'Cmd + Shift + E'
#   Test Package:              'Cmd + Shift + T'

slopediff_all_pairs <- function(model, Round=TRUE, Decimals =3, alpha = 0.05, verbose = TRUE) {
  #### collect results ----
  warning("Predictors variables (Xs) must be on the same measurement scale for a valid comparison.")
  Result <- c()
  result <- c()
  t_test <- 0
  k = 1
  # get coeff diffs
  i = 2
  if("lm" %in% class(model))
  {
    predictors <- names(model$coefficients)
  }
  if("lme" %in% class(model))
  {
    predictors <- names(coef(summary(model))[,"Value"])
  }
  else{
    predictors <- names(coef(summary(model))[,"Estimate"])
  }
  for(i in 2:(length(predictors)-1))
  {
    j = i+1
    while(j < length(predictors)+1)
    {
      result <- .slpdiff_private(model,predictors[i], predictors[j])
      Result <- rbind.data.frame(Result, subset(result, select = -t_test))

      j = j+1
      k = k+1
    }
  }
  m <- (length(predictors)-1)*(length(predictors)-2)/2
  p_value <- as.numeric(Result$`diff_p`)
  ranks<-rank(p_value, ties.method = "last")
  p_m_over_k<-p_value*m/ranks
  pvalues_adj <- c()
  pvalues_sig <- c()
  bonferroni.alpha <- alpha * m
  sidak.alpha <- 1-(1-alpha)^(1/m)
  BH.alpha <- alpha*ranks/m

  for(i in 1:length(p_value))
  {
    # find the rank
    tmp_rank<-ranks[i]
    # get all the p_m_over_k that are greater or equal to this rank
    # and get the min value
    pvalue_BH <- min(1,min(p_m_over_k[ranks>=tmp_rank]))
    pvalues_adj<-c(pvalues_adj, pvalue_BH)
    Result$Bon.p.adj[i]<-(min(1,as.numeric(p_value[i]) * m))
    Result$S.p.adj[i]<- 1-(1-p_value[i])^(m)
   }
  Result$BH.p.adj <- pvalues_adj
  Result$BH.sig <- pvalues_sig
  final <- .print_coef_diff(Result, Round, Decimals, t.test = result$t_test, verbose)
  invisible(final)
}
