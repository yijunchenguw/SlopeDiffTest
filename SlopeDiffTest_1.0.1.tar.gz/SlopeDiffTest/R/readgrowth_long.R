#' ex3 readgrowth_long Dataset
#'
#' A dataset used for lme test example 3
#'
#' @format ## readgrowth_long
#' A dataset used for lme test example 3:
#' \describe{
#'   \item{SubNum2}{subject id number 2}
#'   \item{WID}{WID}
#'
#' }
"readgrowth_long"
