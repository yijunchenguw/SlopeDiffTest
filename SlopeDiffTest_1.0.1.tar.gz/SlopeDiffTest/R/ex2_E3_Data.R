#' ex2 E3 Dataset
#'
#' A dataset used for lme test example 2
#'
#' @format ## ex2_E3_Data
#' A dataset used for lme test example 2:
#' \describe{
#'   \item{SubjectID}{subject id number}
#'   \item{Item}{item nr number}
#'
#' }
"ex2_E3_Data"
