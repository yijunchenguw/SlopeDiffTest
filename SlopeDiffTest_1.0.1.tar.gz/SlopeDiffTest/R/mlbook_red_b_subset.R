#' mlbook red b subset
#'
#' A dataset used for lme test example
#'
#' @format ## mlbook_red_b_subset
#' A dataset used for lme test example:
#' \describe{
#'   \item{schoolnr}{school id number}
#'   \item{pupilNR_new}{pupil nr number}
#'
#' }
"mlbook_red_b_subset"
